// Edit these two values, or set BOT_USERNAME / API_BASE as Pages env vars
// and use a build step to substitute. Simplest: just hardcode.
window.APP_CONFIG = {
  BOT_USERNAME: "YourBotUsername",              // without the @
  API_BASE:     "https://tg-login-api.YOURSUB.workers.dev",
};
